The directory contains two files each having data regarding 20,000 articles. Both files are compressed using gzip. Each decompressed file is in JSON Lines text format. We chose JSON Lines as the format allows for storing structured data that can be processed one record at a time. 

Every line contains data regarding one article in json format. We have shared the title, the url and tags (i.e., keywords) for both clickbait and non-clickbait articles.

This data contains a part of the dataset described in the following paper. If you are using this data for any research publication, or for preparing a technical report, you must cite the paper as the source of the dataset.

Abhijnan Chakraborty, Bhargavi Paranjape, Sourya Kakarla, and Niloy Ganguly. "Stop Clickbait: Detecting and Preventing Clickbaits in Online News Media." In Proceedings of the 2016 IEEE/ACM International Conference on Advances in Social Networks Analysis and Mining (ASONAM), San Fransisco, US, August 2016.